<?php
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2024 Adobe
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe and its suppliers, if any. The intellectual
 * and technical concepts contained herein are proprietary to Adobe
 * and its suppliers and are protected by all applicable intellectual
 * property laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe.
 **************************************************************************/
declare(strict_types=1);

namespace Magento\PaymentServicesPaypal\Api\Data;

interface PaymentConfigGooglePayButtonStylesInterface
{
    public const COLOR = 'color';
    public const HEIGHT = 'height';
    public const TYPE = 'type';

    /**
     * Get color
     *
     * @return string
     */
    public function getColor();

    /**
     * Set color
     *
     * @param string $color
     * @return $this
     */
    public function setColor($color);

    /**
     * Get height
     *
     * @return int
     */
    public function getHeight();

    /**
     * Set height
     *
     * @param int $height
     * @return $this
     */
    public function setHeight($height);

    /**
     * Set type
     *
     * @param $type
     * @return mixed
     */
    public function setType($type);

    /**
     * Get type
     *
     * @return mixed
     */
    public function getType();
}
